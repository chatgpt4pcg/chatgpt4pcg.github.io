# Team Name

A-little-HOPE

## Team Members

Tititpong Wannachai

Nipaporn Phomsak

Jirashcha Wanggum

Kingkarn Sookhanaphibarn

## Overview

This prompt base on knowledge character design and use technique that's is CoT and give some example and write follow instruction.

## Instructions

This programe run by original pacaage on competition and run on python virtual environment

## How to Run

```python
python <filename>.py
```

## Dependencies
python-dotenv~=1.0.0
chatgpt4pcg~=1.2.1