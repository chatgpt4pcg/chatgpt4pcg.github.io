from pathlib import Path
from chatgpt4pcg.competition import run_evaluation, chat_with_chatgpt
from chatgpt4pcg.models.trial_context import TrialContext
from chatgpt4pcg.models.trial_loop import TrialLoop
from dotenv import load_dotenv

# # Use a pipeline as a high-level helper
# from transformers import pipeline
# pipe = pipeline("image-classification", model="pittawat/vit-base-uppercase-english-characters")

# # Load model directly
# from transformers import AutoImageProcessor, AutoModelForImageClassification
# processor = AutoImageProcessor.from_pretrained("pittawat/vit-base-uppercase-english-characters")
# model = AutoModelForImageClassification.from_pretrained("pittawat/vit-base-uppercase-english-characters")

# Initialize the structure as an empty WxH grid
W = 20
H = 16
structure = [[' ']*W for _ in range(H)]

def drop_block(block_type: str, x_position: int):
    # Initialize the drop position at the top of the map
    drop_pos = (H-1, x_position)

    # Drop the block from the top and move it down until it lands on the base or another block
    while drop_pos[0] > 0:
        drop_pos = (drop_pos[0]-1, x_position)
        if structure[drop_pos[0]+1][drop_pos[1]] != ' ':
            break

    # Place the block on the structure
    structure[drop_pos[0]][drop_pos[1]] = block_type

class TreeOfThoughtPrompting(TrialLoop):
    @staticmethod
    def extract_scores(scores_str: str):
        import re
        scores_str = scores_str.lower()
        stability_pattern = r".*stability: (10|\d).*"
        similarity_pattern = r".*similarity: (10|\d).*"
        stability = 0
        similarity = 0
        if stability_match := re.search(stability_pattern, scores_str):
            stability = int(stability_match.group(1))
        if similarity_match := re.search(similarity_pattern, scores_str):
            similarity = int(similarity_match.group(1))
        return stability, similarity

    @staticmethod
    def tot(ctx: TrialContext, target_character: str):
        max_depth = 3
        branching_factor = 2
        current_content = ""

        try:
            for _ in range(max_depth):
                task_prompt_path = Path("SpiralTeam/prompts/task.txt")
                task_prompt = task_prompt_path.read_text().replace("<OBJECT>", target_character).replace(
                    "<GENERATED_CONTENT_SO_FAR>", "Nothing." if current_content == "" else current_content)
                samples = chat_with_chatgpt(ctx, [{
                    "role": "user",
                    "content": task_prompt
                }], n=branching_factor)

                values = []
                for sample in samples:
                    evaluation_prompt_path = Path("SpiralTeam/prompts/evaluate.txt")
                    evaluation_prompt = evaluation_prompt_path.read_text().replace("<OBJECT>", target_character).replace(
                        "<GENERATED_CONTENT_SO_FAR>", current_content + "\n" + sample)
                    evaluation_result = chat_with_chatgpt(ctx, [{
                        "role": "user",
                        "content": evaluation_prompt
                    }])
                    scores = TreeOfThoughtPrompting.extract_scores(evaluation_result[0])
                    values.append((sample, scores))
                values = sorted(values, key=lambda x: x[1], reverse=True)
                if current_content == "":
                    current_content = values[0][0]
                else:
                    current_content += "\n" + values[0][0]

            format_prompt_path = Path("SpiralTeam/prompts/format.txt")
            format_prompt = format_prompt_path.read_text()
            response = chat_with_chatgpt(ctx, [{
                "role": "user",
                "content": format_prompt.replace("<GENERATED_CONTENT>", current_content)
            }])
            final_response = response[0]
        except (ValueError, TimeoutError, FileNotFoundError) as e:
            print(f"Error occurred: {e}")
            final_response = current_content

        return final_response

    @staticmethod
    def run(ctx: TrialContext, target_character: str) -> str:
        """
        Runs the tree-of-thought prompting.
        :param ctx: The trial context.
        :param target_character: The target character.
        :return: The generated text.
        """
        final_response = TreeOfThoughtPrompting.tot(ctx, target_character)

        return final_response

if __name__ == "__main__":
    load_dotenv()
    # inputCharacter = input("Enter the target character: ")
    run_evaluation("SpiralTeam", TreeOfThoughtPrompting)
