# SpiralTeam

## Team Members

Jirawat Damung

Sirasit Tumvijit

Kingkarn Sookhanaphibarn

## Overview

Use matrix by divide full grid size as 4x4 (Assume as pixels) from H16 x W20 | Prompt to generate each matrix and connect to one grid and calculate base from sum of base pixel divide by 3 and remainder is b11 block_type

## Instructions

Not use another lib

## How to Run

In SpiralTeam file run :
python3.11 tot.py

## Dependencies

python-dotenv~=1.0.0
chatgpt4pcg~=1.2.1
