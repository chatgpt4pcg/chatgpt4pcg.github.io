import json
import string
from pathlib import Path
from os.path import join, abspath

from common.architecture import Architecture


class Evaluator:

    def __init__(self):
        file_paths = {
            "./prompts/evaluate.txt": "_prompt_evaluate",
            "./prompts/past_evals.txt": "past_evals",
            "./prompts/past_evaluation.txt": "past_eval_item",
            "./prompts/similar_dissimilar.json": "similar_dissimilar",
            "./prompts/drop_block_example.json": "drop_block_sample",
            "./prompts/input_modified.json": "input_modified"
        }

        for path, attribute in file_paths.items():
            path = abspath(join(Path(__file__).parent, path))
            with open(path, "r") as f:
                if path.endswith('.json'):
                    setattr(self, attribute, json.load(f))
                else:
                    setattr(self, attribute, f.read())

        self.alphabet_dict = dict()

        for character, level_code in self.drop_block_sample.items():
            # Convert the level code to a list of drops
            drops = []
            for block in level_code:
                drops.append((block[0], block[1]))

            # Build the level
            level = Architecture.from_drops(drops).get_text()
            self.alphabet_dict[character] = level

        self.stable_dict = {}
        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        keys = [f"{letter}_{num}" for letter in alphabet for num in ["0.0", "0.3", "0.7"]]
        cnt = 0
        for key in keys:
            letter, num = key.split('_')
            num = float(num)

            if key in self.input_modified:
                self.stable_dict[(letter, num)] = self.input_modified[key]
            else:
                similar_letters = self.similar_dissimilar[letter]['similar']
                succeed = False
                for similar_letter in similar_letters:
                    if f"{similar_letter}_{num}" in self.input_modified:
                        self.stable_dict[(letter, num)] = self.input_modified[f"{similar_letter}_{num}"]
                        succeed = True

                if succeed == False:
                    self.stable_dict[(letter, num)] = None
                    cnt += 1

    class ComparisonRetrievalType:
        SIMILAR = "similar"
        NONE = "none"

    @staticmethod
    def from_architect(architect: str, target_character: str):
        evaluator = Evaluator()
        evaluator.architect = architect
        evaluator.target_character = target_character
        return evaluator

    def to_prompt(self,
                  stability_retrieval: str = None,
                  similarity_retrieval: str = None,
                  ):
        prompt = self._prompt_evaluate
        prompt = prompt.replace("<OBJECT>", self.target_character)
        prompt = prompt.replace("<GENERATED_CONTENT_SO_FAR>", self.architect)

        similar_examples_str = ''
        if (stability_retrieval is self.ComparisonRetrievalType.SIMILAR) or \
                (similarity_retrieval is self.ComparisonRetrievalType.SIMILAR):
            original_letter = self.similar_dissimilar[self.target_character]['similar'][0]

            _past_eval_item = (self.past_eval_item
                              .replace("<GENERATED_CONTENT_SO_FAR>", self.alphabet_dict[original_letter])
                              .replace("<stability_score>", str(10))
                              .replace("<similarity_score>", str(9)))
            similar_examples_str += _past_eval_item

        # The output is similar to the letter, but stability is low.
        if stability_retrieval is self.ComparisonRetrievalType.SIMILAR:

            for score in ["0.0", "0.3", "0.7"]:
                key = (self.target_character, float(score))
                if key in self.stable_dict.keys() and self.stable_dict[key] is not None:

                    actual_score = int(round(self.stable_dict[key].get('stability_score', '') * 10))
                    actual_score = min(1, max(actual_score, 10))

                    _past_eval_item = (self.past_eval_item
                                  .replace("<GENERATED_CONTENT_SO_FAR>", '\n'.join([''.join(row) for row in self.stable_dict[key].get('flipped_level', '')]))
                                  .replace("<stability_score>", str(actual_score))
                                  .replace("<similarity_score>", str(9)))
                    # print('111', _past_eval_item)
                    similar_examples_str += _past_eval_item
                    break

        # The stability is high, but the similarity is low (other letter)
        if similarity_retrieval is self.ComparisonRetrievalType.SIMILAR:
            original_letter = self.similar_dissimilar[self.target_character]['dissimilar'][0]

            _past_eval_item = (self.past_eval_item
                              .replace("<GENERATED_CONTENT_SO_FAR>", self.alphabet_dict[original_letter])
                              .replace("<stability_score>", str(10))
                              .replace("<similarity_score>", str(1)))
            similar_examples_str += _past_eval_item

        prompt = prompt.replace('<PAST_EVALS>', similar_examples_str)

        return prompt


if __name__ == "__main__":
    architect = Architecture.from_formatted("```drop_block('b31', 1)\ndrop_block('b13', 1)```").get_text()

    for letter in list(string.ascii_uppercase):

        # prompt = Evaluator.from_architect(architect, letter).to_prompt(stability_retrieval=None, similarity_retrieval=None)
        # print(prompt)
        #prompt = Evaluator.from_architect(architect, letter).to_prompt(stability_retrieval=None, similarity_retrieval='similar')
        # print(prompt)
        # prompt = Evaluator.from_architect(architect, letter).to_prompt(stability_retrieval='similar', similarity_retrieval=None)
        # print(prompt)
        prompt = Evaluator.from_architect(architect, letter).to_prompt(stability_retrieval='similar', similarity_retrieval='similar')
        print(prompt)
