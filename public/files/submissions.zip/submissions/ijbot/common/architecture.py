import traceback
from typing import List, Tuple
from pprint import pprint
import re
from copy import deepcopy

import numpy as np

H = 16
W = 20


class Architecture:

    def __init__(self):
        self._is_parsed = False
        self._is_built = False
        pass

    @staticmethod
    def from_formatted(formatted_str: str):
        architecture = Architecture()

        formatted_str = formatted_str.replace('```python', '```')
        formatted_str = formatted_str.replace('```\n```', '```')
        formatted_str = formatted_str.replace('\n\n', '\n')
        architecture.prompt = formatted_str.lower().strip().replace('\'', '')
        try:
            architecture._drops = architecture._parse(architecture.prompt)
            architecture._is_parsed = True
            architecture._structure = architecture._build_matrix(architecture._drops)
            architecture._is_built = True
        except Exception as e:
            traceback.print_exc()
            print(architecture.prompt)

        return architecture

    @staticmethod
    def from_drops(drops: List[Tuple[str, int]]):
        architecture = Architecture()
        architecture._drops = drops
        architecture._is_parsed = True
        architecture._structure = architecture._build_matrix(drops)
        architecture._is_built = True
        return architecture

    @property
    def is_parsed(self):
        return self._is_parsed

    @property
    def is_built(self):
        return self._is_built

    def _parse(self, prompt: str):
        lines = re.findall(r'```(.*?)```', prompt, re.DOTALL)[0].strip().splitlines()

        # Step 2: Use regex to extract block identifiers and numbers
        pattern = re.compile(r'drop_block\((b\d+), (\d+)\)')
        extracted_data = [pattern.findall(line.strip())[0] for line in lines]

        # Step 3: Map the extracted data to the provided list
        # Convert extracted data to the required format
        extracted_formatted = [[entry[0].lower(), int(entry[1])] for entry in extracted_data]

        return extracted_formatted

    def _build_matrix(self, drops: List[Tuple[str, int]]):

        structure = [['   ' for _ in range(W)] for _ in range(H)]

        def drop_block(block_type: str, x_position: int):

            block_shapes = {
                'b11': [(0, 0)],
                'b31': [(0, 0), (0, -1), (0, 1)],
                'b13': [(0, 0), (-1, 0), (-2, 0)]
            }

            # initialize the drop position at the top of the map
            drop_pos = (H - 1, x_position)

            stuck = False
            # drop the block from the top and move it down until it lands on the base or another block
            while stuck is False:
                # drop the block by moving it down

                drop_pos = (drop_pos[0] - 1, drop_pos[1])

                # check if the block has landed
                for block_pos in block_shapes[block_type]:
                    pos = (drop_pos[0] + block_pos[0], drop_pos[1] + block_pos[1])
                    if pos[0] == 0 or structure[pos[0] - 1][pos[1]] != '   ':
                        stuck = True

            # place the block on the structure
            for block_pos in block_shapes[block_type]:
                pos = (drop_pos[0] + block_pos[0], drop_pos[1] + block_pos[1])
                if 0 <= pos[0] < H and 0 <= pos[1] < W:
                    structure[pos[0]][pos[1]] = block_type

        for block_type, x_position in drops:
            drop_block(block_type, x_position)

        return structure

    def _get_cropped(self, architecture: list) -> list:
        _architecture = deepcopy(architecture)

        grid_np = np.array(_architecture)

        # Find the first and last non-empty rows
        non_empty_rows = [i for i, row in enumerate(grid_np) if any(cell.strip() for cell in row)]
        first_row, last_row = non_empty_rows[0], non_empty_rows[-1]

        # Find the first and last non-empty columns
        non_empty_cols = [j for j in range(grid_np.shape[1]) if
                          any(grid_np[i, j].strip() for i in range(grid_np.shape[0]))]
        first_col, last_col = non_empty_cols[0], non_empty_cols[-1]

        # Crop the array
        cropped_grid = grid_np[first_row:last_row + 1, first_col:last_col + 1]

        # Convert back to a list of lists (if needed)
        cropped_grid_list = cropped_grid.tolist()

        return cropped_grid_list

    def get_architecture(self):
        return self._structure

    def get_text(self, flipped: bool = True, cropped: bool = True) -> str:

        if not self.is_built:
            return self.prompt + '\n' + '(This level cannot built due to the syntax error)\n'

        output = ''
        level = deepcopy(self._structure)

        if cropped:
            try:
                level = self._get_cropped(level)
            except Exception as e:
                return self.prompt + '\n' + '(Empty space)\n'
        if flipped:
            level = level[::-1]

        for i, row in enumerate(level):
            for col in row:
                output += col
            if i < len(level) - 1:
                output += '\n'

        return output

    def __str__(self):
        return self.get_text()


if __name__ == '__main__':

    content_str = """
      ```
        drop_block(B31, 8)
        drop_block(B11, 9)
        drop_block(B11, 10)
        drop_block(B13, 8)
        drop_block(B11, 8)
        drop_block(B13, 9)
        drop_block(B11, 9)
        drop_block(B13, 10)
        ```     
    """

    content_str = """
    ```
        drop_block('b31', 9)
        drop_block('b13', 9)
        drop_block('b11', 9)
    ```
    """

    architect = Architecture.from_formatted(formatted_str=content_str).get_text()
    print(architect)