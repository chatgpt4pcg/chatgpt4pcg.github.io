from typing import List, Tuple
from pprint import pprint

H = 10
W = 10

def build_level(drops: List[Tuple[str, int]]):

    structure = [['   ' for _ in range(W)] for _ in range(H)]

    def drop_block(block_type: str, x_position: int):

        block_shapes = {
            'b11': [(0, 0)],
            'b31': [(0, 0), (0, -1), (0, 1)],
            'b13': [(0, 0), (-1, 0), (-2, 0)]
        }

        # initialize the drop position at the top of the map
        drop_pos = (H - 1, x_position)

        stuck = False
        # drop the block from the top and move it down until it lands on the base or another block
        while stuck is False:
            # drop the block by moving it down

            drop_pos = (drop_pos[0] - 1, drop_pos[1])

            # check if the block has landed
            for block_pos in block_shapes[block_type]:
                pos = (drop_pos[0] + block_pos[0], drop_pos[1] + block_pos[1])
                if pos[0] == 0 or structure[pos[0] - 1][pos[1]] != '   ':
                    stuck = True

        # place the block on the structure
        for block_pos in block_shapes[block_type]:
            pos = (drop_pos[0] + block_pos[0], drop_pos[1] + block_pos[1])
            if 0 <= pos[0] < H and 0 <= pos[1] < W:
                structure[pos[0]][pos[1]] = block_type

    for block_type, x_position in drops:
        drop_block(block_type, x_position)

    return structure


if __name__ == "__main__":
    sample_level = [
        ["b31", 3],
        ["b11", 2],
        ["b11", 4],
        ["b31", 3],
        ["b11", 2],
        ["b11", 4],
        ["b31", 3]
    ]
    output = build_level(sample_level)

    # Flip the structure vertically
    output = output[::-1]

    pprint(output)