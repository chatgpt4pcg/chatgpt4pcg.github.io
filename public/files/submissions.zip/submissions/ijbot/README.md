# IJ-Bot

## Team Members
- In-Chang Baek (inchang.baek@gm.gist.ac.kr) (GIST, South Korea)
- Jin-Ha Noh (noah9905@gm.gist.ac.kr) (GIST, South Korea)

## Overview
- Utilized N-shot generation prompting, where N=4. The message history is passed into the next generation of the level.
- In the level generation process, we added explanations that are good to consider when creating each alphabet-like maps.
- The previous level and the evaluation history are considered in future generations, enabling the GPT model to generate improved levels through in-context learning.
- The evaluation process is divided into two steps: (1) architecting and (2) evaluation. The architecting process builds the level string into an array heuristically (drop_block). Next, the evaluation proceeds with the architected building via the code.
- During evaluation, we add samples to the evaluation prompt, enabling GPT to score objectively by comparing it with other evaluation samples. We provide samples of unstable levels to GPT when measuring stability.

### Note
- We generated alphabet images using 19 different pixel fonts for each letter. The generated images are used as input for GPT to create explanation texts for generating maps.
- In selecting samples, we retrieved the same or similar alphabet samples of the target character.
- The unstable level dataset is built using the organizor's example, by dropping out arbitrary line of level code.


## Instructions
- This program is written on `Python 3.11`
- Make sure that  below code is imported properly in the `ijbot.py` file.
```python
# ijbot.py
from common import Architecture
from common import Evaluator
```


## How to Run
```
pip install numpy==1.26.4
```

```
python ijbot.py
```

## Dependencies
- numpy==1.26.4
