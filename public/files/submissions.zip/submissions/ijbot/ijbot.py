import string
from pathlib import Path
import re
import random

from os.path import join
from glob import glob

from chatgpt4pcg.competition import chat_with_chatgpt, run_evaluation
from chatgpt4pcg.models.trial_context import TrialContext
from chatgpt4pcg.models.trial_loop import TrialLoop

from common import Architecture
from common import Evaluator


class Result:
    content: str
    score: tuple

    stability_weight = 0
    similarity_weight = 1

    def __str__(self):
        return f"Content: {self.content}\n" \
               f"Score: {self.score}\n"

    @property
    def weighted_score(self):
        return self.score[0] * self.stability_weight + self.score[1] * self.similarity_weight


class ZeroShotMultiTurnPrompting(TrialLoop):
    @staticmethod
    def extract_scores(scores_str: str):
        import re
        scores_str = scores_str.lower()
        stability_pattern = r"stability: (\d+)"
        similarity_pattern = r"similarity: (\d+)"
        stability = 0
        similarity = 0
        if stability_match := re.search(stability_pattern, scores_str):
            stability = int(stability_match.group(1))
        if similarity_match := re.search(similarity_pattern, scores_str):
            similarity = int(similarity_match.group(1))
        return stability, similarity


    @staticmethod
    def get_level_db():
        LEVEL_DB = 'level_db'

        db = dict()

        for character in list(string.ascii_uppercase):
            samples = glob(join(LEVEL_DB, f'{character}.txt'))

            db[character] = list()
            for sample in samples:
                with open(sample, 'r', encoding='utf-8') as f:
                    ascii = f.read()
                    db[character].append(ascii)

        return db

    @staticmethod
    def run(ctx: TrialContext, target_character: str) -> str:

        level_db = ZeroShotMultiTurnPrompting.get_level_db()

        """
        Runs the zero-shot multi-turn prompting.
        :param ctx: The trial context.
        :param target_character: The target character.
        :return: The generated text.
        """
        prompts = [file for file in Path("prompts").glob("*.txt")]

        # sort prompts with the numbers
        prompts = sorted(prompts, key=lambda x: int(x.stem.split(".")[0]))

        max_depth = 4
        results = list()

        history = []

        try:
            for _ in range(max_depth):

                result = Result()

                for prompt in prompts:
                    prompt_template = open(prompt, "r", encoding='utf-8').read()

                    prompt_template = prompt_template.replace("<OBJECT>", target_character)

                    alphabet_db = level_db[target_character]
                    structure = random.sample(alphabet_db, 1)[0]

                    # Few-shot
                    prompt_template = prompt_template.replace("<STRUCTURE_SHAPE>", structure)

                    if str(prompt) == 'prompts/2.txt':
                        estimated = Architecture.from_formatted(result.content).get_text()
                        prompt_template = Evaluator.from_architect(estimated, target_character).to_prompt(
                            similarity_retrieval='similar', stability_retrieval='similar'
                        )

                    history.append({"role": "user", "content": prompt_template})
                    response = chat_with_chatgpt(ctx, history[-5:])[0]
                    history.append({"role": "assistant", "content": response})
                    pattern_1 = r'prompts.*1.txt'
                    pattern_2 = r'prompts.*2.txt'
                    if re.search(pattern_1, str(prompt)):
                        result.content = response
                    elif re.search(pattern_2, str(prompt)):
                        result.score = ZeroShotMultiTurnPrompting.extract_scores(response)

                results.append(result)
        except (ValueError, TimeoutError, IndexError) as e:
            pass
            print(e)

        best_result = max(results, key=lambda x: x.weighted_score)
        final_response = best_result.content

        print(f"{target_character}: {ctx.get_total_token_count()} token used")

        return final_response


if __name__ == "__main__":
    run_evaluation("ijbot", ZeroShotMultiTurnPrompting, num_trials=10, characters=list(string.ascii_uppercase))