# Team Name
Shot_Few

## Team Members

TIAN Chenglin
Musashi Wakamatsu

## Overview

Our team created a prompt that incorporated the few_shot. We aimed to improve stability and similarity by showing by example how to place all letter blocks.

## Instructions

Create a virtual environment to run the code. You can create a virtual environment through conda. To create a virtual environment using conda, you can run the following command:
```bash
conda create -n chatgpt4pcg python=3.11
```
Once you have created the virtual environment, you can activate the virtual environment by running the following
command:

```bash
conda activate chatgpt4pcg
```

To run, you need to install the required packages. You can install the required packages by running the
following command:

```bash
pip install -r requirements.txt
```

## How to Run

To run it, you need to set an environment variable in the file. There is an environment variable named OPENAI_API_KEY in the .env file in the folder, so enter the OpenAI API key you obtained here.
After setting the environment variables, you can run the code by running the following command:

```bash
python few_shot/few_shot.py
```
Since it is set up to generate only one character trial, you will need to change the characters variable in the run_evaluation function to change the character.
For example, if you want to change the character to B, you must do the following:
```python
run_evaluation("few_shot", FewShotPrompting, num_trials=10, characters=["B"])
```

## Dependencies

python-dotenv=1.0.0
chatgpt4pcg=1.2.1

```python
from pathlib import Path

from chatgpt4pcg.competition import chat_with_chatgpt, run_evaluation
from chatgpt4pcg.models.trial_context import TrialContext
from chatgpt4pcg.models.trial_loop import TrialLoop
from dotenv import load_dotenv
```
