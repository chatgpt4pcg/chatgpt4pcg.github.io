# Team Name
IBMGPT

## Team Members

Ibrahim Khan

## Overview

I utilized the many-shot approach to achieve more accuracy, but this came at the expense of diversity. Although I added a specific instruction at the end to make the output more diverse, this approach was not effective in creating diverse outputs

## Instructions

Just run the Many_shot.py

## How to Run

Just run the Many_shot.py

## Dependencies

Same as the chatgpt4pcg2 project.