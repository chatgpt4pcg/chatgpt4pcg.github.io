# Team Name

ChuangYe


## Team Members

Chuang Boyu
YE SHOUCHEN

## Overview

Use tot to modify some prompts and add additional examples.

## Instructions

The zip contains tot, .env, requirements.txt, readme.txt

There are prompts, __init__.py, tot.py in the tot folder.

The prompts folder contains evaluate.txt, format.txt, task.txt. 3 prompts required by tot.


## How to Run

Same as competition example.

Create a virtual environment using conda, you can run the following command:

conda create -n chatgpt4pcg2 python=3.11

Once you have created the virtual environment, you can activate the virtual environment by running the following command:

conda activate chatgpt4pcg2

Need to install the required packages. You can install the required packages by running the following command:

pip install -r requirements.txt

To run the tot, you can run the following command

python tot/tot.py
