# Team Name

TheAlmostEngineer

## Team Members

Filippo Guadagnini
Pierluca Lanzi
Daniele Loiacono


## Overview

The solution implemented consists on the use of the library Graph of Thoughs.
In particular, 2 nodes are implemented, aiming at three for the final submission:
- a GENERATE node, taking as input one of the 4 different generate_prompt which gives as answer the desired letter of the alphabet built in differemt ways;
- an IMPROVE node, taking as input the improve_prompt which, given a sequence of drop_block() function calls identifying a letter of the alphabet, gives as output a shifted version to create a diverse solution;
An additional log folder, other than the one for the competition, is created for testing while using the offered log solution of GoT library.

## Instructions

The prgram runs with Python 3.11.9
To run the program, create an .env file containing the API key for the OpenAI api such as the one in .env.example
To run the program, one must create a virtual environment using either conda or venv.
For my solution, I created a virtual env with the instruction sequence
- conda create -n chatgpt4pcg2 python=3.11
- conda activate chatgpt4pcg2
The only additional requirment to be installed can be found in the requirments.txt (dotenv) and to install
- pip install -r requirements.txt

## How to Run

After setting up the personal api key and activating the virtual environment, one can run the main script using
python competitionMain.py

## Dependencies

- chatgpt4pcg library in order to meet the requirments for the competition
- Graph of Thoughs library modified in order to include chatgpt4pcg library