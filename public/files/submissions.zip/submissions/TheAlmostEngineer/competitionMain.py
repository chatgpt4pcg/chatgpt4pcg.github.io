from pathlib import Path

from chatgpt4pcg.competition import chat_with_chatgpt, run_evaluation
from chatgpt4pcg.models.trial_context import TrialContext
from chatgpt4pcg.models.trial_loop import TrialLoop
from dotenv import load_dotenv

from graph_of_thoughts import controller, operations, prompter, parser

import logging

import datetime
import time
import os
import logging
import json
from typing import Dict, List, Union
from random import randint


class Prompter(prompter.Prompter):

    '''
    Class generating the prompt given to the LLM.
    '''

    improve_prompt_txt = open(Path("prompts/improve.txt"), "r").read()

    original_answer = []

    def generate_prompt(
        self,
        num_branches: int,
        **kwargs,
    ) -> str:
        '''
        Generate a vocabulary giving the representation of the desired character.
        '''

        vocabulary_path = "prompts/generate_"
        vocabulary_number = str(randint(1, 4))
        vocabulary_path += vocabulary_number + ".txt"

        generate_prompt_txt = open(Path(vocabulary_path), "r").read()

        return generate_prompt_txt

    def improve_prompt(self, state_dicts: List[Dict], **kwargs) -> str:
        '''
        Generate the shifting prompt to create even more diversity.
        '''

        values_random = ""

        for i in range(5):
            values_random += str(randint(-5, 5))
            if i == 5:
                values_random += "\n"
            else:
                values_random += ", "

        new_improve_prompt = ""

        new_improve_prompt += self.improve_prompt_txt
        new_improve_prompt = new_improve_prompt.replace("<SEQUENCE>", self.original_answer[0])
        new_improve_prompt = new_improve_prompt.replace("<VALUES>", values_random)

        return new_improve_prompt

    def set_original_answer(self, texts: list[str]) -> None:
        self.original_answer = texts[0]




class Parser(parser.Parser):
    '''
    Class which parse the answer from the LLM
    '''

    original_answer = []
    answer = []
    best_answer = []

    def __init__(self) -> None:
        """
        Inits the response cache.
        """
        self.cache = {}

    def parse_improve_answer(self, state: Dict, texts: list[str]) -> Dict:
        '''
        Parse the improve answer. This answer is the one that will be saved to the final output.
        '''
        new_states = []

        self.answer = texts[0]

        logging.debug("ANSWER: %s", self.answer)

        for text in texts:
            try:

                answers = text.strip().split("\n")

                answers = [
                    answer for answer in answers
                ]

                new_state = state.copy()

                new_state["sequence"] = answers
                new_states.append(new_state)

            except Exception as e:
                logging.error(
                    f"Could not parse step answer: {answers}. Encountered exception: {e}"
                )

        return new_states[0]




    def parse_generate_answer(self, state: Dict, texts: list[str]) -> List[Dict]:
        '''
        Parse of the vocabulary answer.
        The answer will be saved as the original answer in order to use it as the input of the improve prompt.
        '''

        new_states = []

        self.original_answer = texts[0]

        logging.debug("ORIGINAL ANSWER: %s", self.original_answer)

        for text in texts:
            try:

                answers = text.strip().split("\n")

                answers = [
                    answer for answer in answers
                ]

                new_state = state.copy()

                new_state["sequence"] = answers
                new_states.append(new_state)

            except Exception as e:
                logging.error(
                    f"Could not parse step answer: {answers}. Encountered exception: {e}"
                )

        return new_states


def got() -> operations.GraphOfOperations:
    '''
    Generation of the Graph of Thought solution.
    The solution is simple:
    - one GENERATE to output the character from the vocabulary;
    - one IMPROVE to output the shifted version of the GENERATE prompt.
    '''

    operations_graph = operations.GraphOfOperations()
    operations_graph.append_operation(operations.Generate(1, 1))
    operations_graph.append_operation(operations.Improve())

    return operations_graph


class CompetitionPrompting(TrialLoop):
    @staticmethod
    def run(ctx: TrialContext, target_character: str) -> str:
        '''
        :param ctx: The trial context.
        :param target_character: The target character.
        :return: The generated text.
        '''

        '''
        Init of the logs folders for the GoT method (not to be considered for the final ouput).
        This generated, other than the logs, the json files containing the answers.
        '''

        results_dir = os.path.join(os.path.dirname(__file__), "results")

        if not os.path.exists(results_dir):
            os.makedirs(results_dir)
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        folder_name = f"{timestamp}_{target_character}"
        results_folder = os.path.join(results_dir, folder_name)
        os.makedirs(results_folder)

        config = {
            "data": target_character,
        }
        with open(os.path.join(results_folder, "config.json"), "w") as f:
            json.dump(config, f)

        logging.basicConfig(
            filename=os.path.join(results_dir, "log.log"),
            filemode="w",
            format="%(name)s - %(levelname)s - %(message)s",
            level=logging.DEBUG,
        )

        responses = []

        '''
        Controller init.
        '''

        executor = controller.Controller(
                got(),
                Prompter(),
                Parser(),
                {
                    "request": target_character,
                    "sequence": "",
                },
                ctx,
                target_character,
            )
        try:
            responses = executor.run()
        except Exception as e:
            logging.error(f"Exception: {e}")

        path = os.path.join(
                results_folder,f"{target_character}.json",
        )
        executor.output_graph(path)

        logging.debug("Responses from LM: %s", responses)

        response = responses[0]

        return str(response)


if __name__ == "__main__":
    load_dotenv()
    run_evaluation("resultMain", CompetitionPrompting)
